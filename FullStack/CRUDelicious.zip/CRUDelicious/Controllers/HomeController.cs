﻿// using System.Diagnostics;
// using Microsoft.AspNetCore.Mvc;
// using CRUDelicious.Models;

// namespace CRUDelicious.Controllers;

// public class HomeController : Controller
// {
//     private readonly ILogger<HomeController> _logger;

//     private DishContext _context;
//     public HomeController(ILogger<HomeController> logger, DishContext context)
//     {
//         _logger = logger;

//         _context= context;
//     }

    // public IActionResult Index()
    // {
    //     List<Dish> AllDishes= _context.Dishes.ToList();
    //     return View();
    // }

    
// }
