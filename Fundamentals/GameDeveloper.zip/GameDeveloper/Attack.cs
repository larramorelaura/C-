public class Attack
{
    public string Name;

    public int DamageAmount;

    public Attack(string n, int amt)
    {
        Name=n;
        DamageAmount=amt;
    }
}